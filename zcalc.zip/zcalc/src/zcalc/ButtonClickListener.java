package zcalc;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonClickListener implements ActionListener {
    private JTextField display;
    private State state;

    public ButtonClickListener(JTextField display, State state) {
        this.display = display;
        this.state = state;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.equals("C")) {
            state.clear();
            display.setText("");
        } else if (command.equals("=")) {
            // Aggiorna lo stato con l'input corrente dal display
            state.setCurrentInput(display.getText());
            display.setText(state.calculate());
        } else if (command.equals("Del")) {
            String currentText = display.getText();
            if (currentText.length() > 0) {
                display.setText(currentText.substring(0, currentText.length() - 1));
            }
        } else {
            display.setText(display.getText() + command);
        }
    }
}

