package zcalc;


import javax.swing.SwingUtilities;

public class CalculatorMain {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ZCalc calculator = new ZCalc();
            calculator.setVisible(true);
        });
    }
}

