package zcalc;
import javax.swing.*;
import java.awt.*;

public class ZCalc extends JFrame {
    private JTextField display;
    private State state;
    public ZCalc() {
        state = new State();
        setTitle("Calcolatrice");
        setSize(300, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        display = new JTextField();
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("boh", Font.BOLD, 24));
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 10, 10));
        String[] buttons = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+",
            "Del"
        };
        for (String text : buttons) {
            JButton button = new JButton(text);
            button.setFont(new Font("boh", Font.PLAIN, 24));
            button.addActionListener(new ButtonClickListener(display, state));
            button.setFocusable(false);
            panel.add(button);
        }
        setLayout(new BorderLayout());
        add(display, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);
    }
}

