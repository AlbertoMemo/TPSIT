package zcalc;
import java.util.Stack;
public class State {
    private Stack<Double> memory;
    private StringBuilder currentInput;
    public State() {
        memory = new Stack<>();
        currentInput = new StringBuilder();
    }
    public void clear() {
        memory.clear();
        currentInput.setLength(0);
    }
    public void setCurrentInput(String input) {
        currentInput.setLength(0);
        currentInput.append(input);
    }
    public String calculate() {
        try {
            if (currentInput.length() == 0) {
                return "0";
            }
            double result = eval(currentInput.toString());
            memory.push(result);
            currentInput.setLength(0);
            currentInput.append(result);
            return String.valueOf(result);
        } catch (Exception e) {
            clear();
            return "Errore";
        }
    }
    private double eval(String expression) {
        return new Object() {
            int pos = -1, ch;
            void nextChar() {
                ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
            }
            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }
            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < expression.length()) throw new RuntimeException("" + (char) ch);
                return x;
            }
            double parseExpression() {
                double x = parseTerm();
                while (true) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }
            double parseTerm() {
                double x = parseFactor();
                while (true) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }
            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();
                double x;
                int startPos = this.pos;
                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(expression.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }
                return x;
            }
        }.parse();
    }
}


