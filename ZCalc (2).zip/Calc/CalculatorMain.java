package zcalc;
import javax.swing.*;
public class CalculatorMain {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            ZCalc calculator = new ZCalc();
            calculator.setVisible(true);
        });
    }
}

