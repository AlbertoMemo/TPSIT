package zcalc;

import java.util.Stack;

public class State {

    private Stack<Double> memory;
    private StringBuilder currentInput;

    
    public State() {
        memory = new Stack<>();
        currentInput = new StringBuilder();
    }

    // resetta lo stato della calcolatrice
    public void clear() {
        memory.clear();
        currentInput.setLength(0);
    }
    // fa l'input corrente
    public void setCurrentInput(String input) {
        currentInput.setLength(0);
        currentInput.append(input);
    }
    // fa il calcolo dell'espressione
    public String calculate() {
        try {
            if (currentInput.length() == 0) {
                return "0"; 
            }

            double result = evalExpression(currentInput.toString());
            memory.push(result); // il risultato nello stack
            currentInput.setLength(0); // resetta l'input corrente
            currentInput.append(result); // mette il risultato come nuovo input

            return String.valueOf(result);
        } catch (Exception e) {
            clear(); // resetta lo stato in caso di errore
            return "Errore"; 
        }
    }
    public double evalExpression(String expression) {
        char[] chars = expression.toCharArray();
        int[] index = {0}; 
        return parseExpression(chars, index);
    }
    public double parseExpression(char[] chars, int[] index) {
        double result = parseTerm(chars, index);
        while (index[0] < chars.length) {
            char operator = chars[index[0]];
            if (operator == '+' || operator == '-') {
                index[0]++;
                double value = parseTerm(chars, index);
                if (operator == '+') {
                    result += value;
                } else {
                    result -= value;
                }
            } else {
                break;
            }
        }

        return result;
    }
    public double parseTerm(char[] chars, int[] index) {
        double result = parseFactor(chars, index);
        while (index[0] < chars.length) {
            char operator = chars[index[0]];
            if (operator == '*' || operator == '/') {
                index[0]++;
                double value = parseFactor(chars, index);
                if (operator == '*') {
                    result *= value;
                } else {
                    result /= value;
                }
            } else {
                break;
            }
        }

        return result;
    }
    public double parseFactor(char[] chars, int[] index) {
        StringBuilder number = new StringBuilder();
        while (index[0] < chars.length && (Character.isDigit(chars[index[0]]) || chars[index[0]] == '.')) {
            number.append(chars[index[0]]);
            index[0]++;
        }

        if (number.length() > 0) {
            return Double.parseDouble(number.toString());
        }
        throw new IllegalArgumentException("Input non valido");
    }
}
